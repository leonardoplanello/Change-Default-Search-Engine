// background.js

chrome.runtime.onInstalled.addListener(() => {
    console.log("Change Default Search Engine instalado com sucesso!");
  });
  